# API 文档

## 认证

### POST /api/auth/login

请求：

```json
{
  "username": "admin",
  "password": "123456"
}
```

响应：

```json
{
  "code": 0,
  "message": "success",
  "success": true,
  "data": {
    "token": "...",
    "userId": 1,
    "username": "admin",
    "realName": "系统管理员",
    "role": "ADMIN"
  }
}
```

后续接口 Header：

```text
Authorization: Bearer <token>
```

## 用户

### GET /api/users

获取成员列表。

## 任务

### POST /api/tasks

创建任务。

```json
{
  "title": "检查昨日异常订单",
  "description": "筛选支付成功但未分账订单",
  "priority": "HIGH",
  "assigneeId": 2
}
```

### GET /api/tasks

查询任务。

可选参数：

```text
status=TODO
assigneeId=2
```

### PUT /api/tasks/{id}/status

修改状态。

```json
{
  "status": "DONE"
}
```

### POST /api/tasks/{id}/comments

评论任务。

```json
{
  "content": "已处理，等待复核"
}
```

## 自动化规则

### GET /api/automation-rules

查询规则。

### POST /api/automation-rules

创建规则，仅 ADMIN 可操作。

```json
{
  "name": "任务创建通知",
  "triggerType": "TASK_CREATED",
  "actionType": "CREATE_NOTIFICATION",
  "actionConfig": "有新任务需要处理",
  "enabled": true
}
```

## 通知

### GET /api/notifications

查询当前用户通知。

## 审计

### GET /api/audit-logs

查询审计日志，仅 ADMIN 可操作。
