package com.example.collabops.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.collabops.domain.*;import java.util.List;public interface OpsTaskRepository extends JpaRepository<OpsTask, Long>{ List<OpsTask> findByAssigneeIdOrderByUpdatedAtDesc(Long assigneeId); List<OpsTask> findByStatusOrderByUpdatedAtDesc(TaskStatus status); }
