package com.example.collabops.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.collabops.domain.*;import java.util.List;public interface AutomationRuleRepository extends JpaRepository<AutomationRule, Long>{ List<AutomationRule> findByEnabledTrueAndTriggerType(AutomationTrigger triggerType); }
