package com.example.collabops.security;

import com.example.collabops.common.BizException;
import com.example.collabops.domain.User;
import com.example.collabops.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class CurrentUser {
    private final UserRepository userRepository;

    public CurrentUser(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User get() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || authentication.getName() == null) {
            throw new BizException("未登录");
        }
        return userRepository.findByUsername(authentication.getName())
                .orElseThrow(() -> new BizException("用户不存在"));
    }

    public String username() {
        return get().getUsername();
    }
}
