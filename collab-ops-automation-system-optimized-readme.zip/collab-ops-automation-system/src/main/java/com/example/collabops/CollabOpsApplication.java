package com.example.collabops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollabOpsApplication {
    public static void main(String[] args) {
        SpringApplication.run(CollabOpsApplication.class, args);
    }
}
