package com.example.collabops.config;

import com.example.collabops.domain.*;
import com.example.collabops.repository.AutomationRuleRepository;
import com.example.collabops.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;

@Configuration
public class DataInitializer {
    @Bean
    public CommandLineRunner initData(UserRepository userRepository,
                                      AutomationRuleRepository ruleRepository,
                                      PasswordEncoder passwordEncoder) {
        return args -> {
            if (userRepository.count() == 0) {
                userRepository.save(User.builder()
                        .username("admin").password(passwordEncoder.encode("123456"))
                        .realName("系统管理员").role(Role.ADMIN).enabled(true).createdAt(LocalDateTime.now()).build());
                userRepository.save(User.builder()
                        .username("operator").password(passwordEncoder.encode("123456"))
                        .realName("运营专员").role(Role.OPERATOR).enabled(true).createdAt(LocalDateTime.now()).build());
                userRepository.save(User.builder()
                        .username("viewer").password(passwordEncoder.encode("123456"))
                        .realName("只读用户").role(Role.VIEWER).enabled(true).createdAt(LocalDateTime.now()).build());
            }

            if (ruleRepository.count() == 0) {
                ruleRepository.save(AutomationRule.builder()
                        .name("高优任务创建通知")
                        .triggerType(AutomationTrigger.TASK_CREATED)
                        .actionType(AutomationAction.CREATE_NOTIFICATION)
                        .actionConfig("任务已创建，请及时处理")
                        .enabled(true)
                        .createdAt(LocalDateTime.now())
                        .build());
                ruleRepository.save(AutomationRule.builder()
                        .name("紧急任务自动进入处理中")
                        .triggerType(AutomationTrigger.TASK_PRIORITY_URGENT)
                        .actionType(AutomationAction.MARK_IN_PROGRESS)
                        .actionConfig("紧急任务自动进入处理中")
                        .enabled(true)
                        .createdAt(LocalDateTime.now())
                        .build());
            }
        };
    }
}
