package com.example.collabops.domain;

public enum AutomationTrigger {
    TASK_CREATED,
    TASK_STATUS_CHANGED,
    TASK_PRIORITY_URGENT
}
