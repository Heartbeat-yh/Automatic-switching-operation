package com.example.collabops.dto;

import com.example.collabops.domain.Priority;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
public class TaskCreateRequest {
    @NotBlank(message = "任务标题不能为空")
    private String title;
    private String description;
    @NotNull(message = "优先级不能为空")
    private Priority priority;
    private Long assigneeId;
    private LocalDateTime dueAt;
}
