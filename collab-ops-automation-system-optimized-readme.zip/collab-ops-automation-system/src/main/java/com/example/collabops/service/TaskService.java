package com.example.collabops.service;

import com.example.collabops.common.BizException;
import com.example.collabops.domain.*;
import com.example.collabops.dto.*;
import com.example.collabops.repository.*;
import com.example.collabops.security.CurrentUser;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class TaskService {
    private final OpsTaskRepository taskRepository;
    private final UserRepository userRepository;
    private final TaskCommentRepository commentRepository;
    private final CurrentUser currentUser;
    private final AuditService auditService;
    private final AutomationService automationService;

    public TaskService(OpsTaskRepository taskRepository,
                       UserRepository userRepository,
                       TaskCommentRepository commentRepository,
                       CurrentUser currentUser,
                       AuditService auditService,
                       AutomationService automationService) {
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
        this.commentRepository = commentRepository;
        this.currentUser = currentUser;
        this.auditService = auditService;
        this.automationService = automationService;
    }

    @Transactional
    public OpsTask create(TaskCreateRequest request) {
        User creator = currentUser.get();
        User assignee = null;
        if (request.getAssigneeId() != null) {
            assignee = userRepository.findById(request.getAssigneeId())
                    .orElseThrow(() -> new BizException("指派用户不存在"));
        }

        OpsTask task = OpsTask.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .priority(request.getPriority())
                .status(TaskStatus.TODO)
                .creator(creator)
                .assignee(assignee)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .dueAt(request.getDueAt())
                .build();
        taskRepository.save(task);

        auditService.log(creator.getUsername(), "CREATE_TASK", "TASK", String.valueOf(task.getId()), task.getTitle());
        automationService.trigger(AutomationTrigger.TASK_CREATED, task);
        if (task.getPriority() == Priority.URGENT) {
            automationService.trigger(AutomationTrigger.TASK_PRIORITY_URGENT, task);
        }
        return task;
    }

    public List<OpsTask> list(Optional<TaskStatus> status, Optional<Long> assigneeId) {
        if (assigneeId.isPresent()) {
            return taskRepository.findByAssigneeIdOrderByUpdatedAtDesc(assigneeId.get());
        }
        if (status.isPresent()) {
            return taskRepository.findByStatusOrderByUpdatedAtDesc(status.get());
        }
        return taskRepository.findAll();
    }

    @Transactional
    public OpsTask changeStatus(Long taskId, TaskStatusRequest request) {
        User operator = currentUser.get();
        OpsTask task = taskRepository.findById(taskId).orElseThrow(() -> new BizException("任务不存在"));
        TaskStatus old = task.getStatus();
        task.setStatus(request.getStatus());
        task.setUpdatedAt(LocalDateTime.now());
        taskRepository.save(task);
        auditService.log(operator.getUsername(), "CHANGE_STATUS", "TASK", String.valueOf(taskId), old + " -> " + request.getStatus());
        automationService.trigger(AutomationTrigger.TASK_STATUS_CHANGED, task);
        return task;
    }

    @Transactional
    public TaskComment comment(Long taskId, CommentRequest request) {
        User user = currentUser.get();
        OpsTask task = taskRepository.findById(taskId).orElseThrow(() -> new BizException("任务不存在"));
        TaskComment comment = TaskComment.builder()
                .task(task)
                .user(user)
                .content(request.getContent())
                .createdAt(LocalDateTime.now())
                .build();
        commentRepository.save(comment);
        auditService.log(user.getUsername(), "COMMENT_TASK", "TASK", String.valueOf(taskId), request.getContent());
        return comment;
    }

    public List<TaskComment> comments(Long taskId) {
        return commentRepository.findByTaskIdOrderByCreatedAtAsc(taskId);
    }
}
