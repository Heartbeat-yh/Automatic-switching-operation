package com.example.collabops.domain;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "notification")
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch=FetchType.LAZY)
    private User receiver;

    @Column(nullable=false, length=128)
    private String title;

    @Column(nullable=false, length=1000)
    private String content;

    @Column(nullable=false)
    private Boolean readFlag;

    private LocalDateTime createdAt;
}
