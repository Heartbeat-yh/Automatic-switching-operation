package com.example.collabops.controller;

import com.example.collabops.common.ApiResponse;
import com.example.collabops.domain.Notification;
import com.example.collabops.security.CurrentUser;
import com.example.collabops.service.NotificationService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    private final NotificationService notificationService;
    private final CurrentUser currentUser;

    public NotificationController(NotificationService notificationService, CurrentUser currentUser) {
        this.notificationService = notificationService;
        this.currentUser = currentUser;
    }

    @GetMapping
    public ApiResponse<List<Notification>> list() {
        return ApiResponse.ok(notificationService.list(currentUser.get().getId()));
    }
}
