package com.example.collabops.dto;

import com.example.collabops.domain.AutomationAction;
import com.example.collabops.domain.AutomationTrigger;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class AutomationRuleRequest {
    @NotBlank(message = "规则名称不能为空")
    private String name;
    @NotNull(message = "触发类型不能为空")
    private AutomationTrigger triggerType;
    @NotNull(message = "动作类型不能为空")
    private AutomationAction actionType;
    private String actionConfig;
    private Boolean enabled = true;
}
