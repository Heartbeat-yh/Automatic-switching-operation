package com.example.collabops.domain;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ops_task")
public class OpsTask {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false, length=128)
    private String title;

    @Column(length=2000)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable=false, length=32)
    private TaskStatus status;

    @Enumerated(EnumType.STRING)
    @Column(nullable=false, length=32)
    private Priority priority;

    @ManyToOne(fetch = FetchType.LAZY)
    private User creator;

    @ManyToOne(fetch = FetchType.LAZY)
    private User assignee;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime dueAt;
}
