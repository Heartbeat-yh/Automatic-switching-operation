package com.example.collabops.common;

public class BizException extends RuntimeException {
    public BizException(String message) {
        super(message);
    }
}
