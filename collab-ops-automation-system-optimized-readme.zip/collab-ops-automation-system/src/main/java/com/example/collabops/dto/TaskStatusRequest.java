package com.example.collabops.dto;

import com.example.collabops.domain.TaskStatus;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class TaskStatusRequest {
    @NotNull(message = "任务状态不能为空")
    private TaskStatus status;
}
