package com.example.collabops.controller;

import com.example.collabops.common.ApiResponse;
import com.example.collabops.domain.User;
import com.example.collabops.repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR','VIEWER')")
    public ApiResponse<List<User>> list() {
        return ApiResponse.ok(userRepository.findAll());
    }
}
