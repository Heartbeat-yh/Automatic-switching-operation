package com.example.collabops.domain;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}
