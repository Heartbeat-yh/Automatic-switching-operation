package com.example.collabops.domain;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "task_comment")
public class TaskComment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch=FetchType.LAZY)
    private OpsTask task;

    @ManyToOne(fetch=FetchType.LAZY)
    private User user;

    @Column(nullable=false, length=2000)
    private String content;

    private LocalDateTime createdAt;
}
