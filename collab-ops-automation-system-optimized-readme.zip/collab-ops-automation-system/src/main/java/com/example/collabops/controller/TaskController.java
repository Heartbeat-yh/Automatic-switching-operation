package com.example.collabops.controller;

import com.example.collabops.common.ApiResponse;
import com.example.collabops.domain.*;
import com.example.collabops.dto.*;
import com.example.collabops.service.TaskService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {
    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public ApiResponse<OpsTask> create(@Valid @RequestBody TaskCreateRequest request) {
        return ApiResponse.ok(taskService.create(request));
    }

    @GetMapping
    public ApiResponse<List<OpsTask>> list(@RequestParam Optional<TaskStatus> status,
                                           @RequestParam Optional<Long> assigneeId) {
        return ApiResponse.ok(taskService.list(status, assigneeId));
    }

    @PutMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public ApiResponse<OpsTask> changeStatus(@PathVariable Long id, @Valid @RequestBody TaskStatusRequest request) {
        return ApiResponse.ok(taskService.changeStatus(id, request));
    }

    @PostMapping("/{id}/comments")
    @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    public ApiResponse<TaskComment> comment(@PathVariable Long id, @Valid @RequestBody CommentRequest request) {
        return ApiResponse.ok(taskService.comment(id, request));
    }

    @GetMapping("/{id}/comments")
    public ApiResponse<List<TaskComment>> comments(@PathVariable Long id) {
        return ApiResponse.ok(taskService.comments(id));
    }
}
