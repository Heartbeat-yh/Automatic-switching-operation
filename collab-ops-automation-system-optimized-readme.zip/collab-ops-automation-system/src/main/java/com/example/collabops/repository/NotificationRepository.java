package com.example.collabops.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.collabops.domain.Notification;import java.util.List;public interface NotificationRepository extends JpaRepository<Notification, Long>{ List<Notification> findByReceiverIdOrderByCreatedAtDesc(Long receiverId); }
