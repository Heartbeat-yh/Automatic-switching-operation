package com.example.collabops.domain;

public enum AutomationAction {
    CREATE_NOTIFICATION,
    MARK_IN_PROGRESS
}
