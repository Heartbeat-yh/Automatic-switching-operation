package com.example.collabops.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.collabops.domain.AuditLog;public interface AuditLogRepository extends JpaRepository<AuditLog, Long>{ }
