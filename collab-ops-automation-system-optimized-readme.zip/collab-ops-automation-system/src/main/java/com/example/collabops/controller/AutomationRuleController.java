package com.example.collabops.controller;

import com.example.collabops.common.ApiResponse;
import com.example.collabops.domain.AutomationRule;
import com.example.collabops.dto.AutomationRuleRequest;
import com.example.collabops.service.AutomationRuleService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/automation-rules")
public class AutomationRuleController {
    private final AutomationRuleService service;

    public AutomationRuleController(AutomationRuleService service) {
        this.service = service;
    }

    @GetMapping
    public ApiResponse<List<AutomationRule>> list() {
        return ApiResponse.ok(service.list());
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ApiResponse<AutomationRule> create(@Valid @RequestBody AutomationRuleRequest request) {
        return ApiResponse.ok(service.create(request));
    }
}
