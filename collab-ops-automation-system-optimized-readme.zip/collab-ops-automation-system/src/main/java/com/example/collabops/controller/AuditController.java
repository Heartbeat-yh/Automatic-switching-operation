package com.example.collabops.controller;

import com.example.collabops.common.ApiResponse;
import com.example.collabops.domain.AuditLog;
import com.example.collabops.repository.AuditLogRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/audit-logs")
public class AuditController {
    private final AuditLogRepository repository;

    public AuditController(AuditLogRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ApiResponse<List<AuditLog>> list() {
        return ApiResponse.ok(repository.findAll());
    }
}
