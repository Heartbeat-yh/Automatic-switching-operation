package com.example.collabops.domain;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "audit_log")
public class AuditLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length=64)
    private String operator;

    @Column(nullable=false, length=64)
    private String action;

    @Column(length=64)
    private String bizType;

    @Column(length=64)
    private String bizId;

    @Column(length=2000)
    private String detail;

    private LocalDateTime createdAt;
}
