package com.example.collabops.domain;

public enum Role {
    ADMIN,
    OPERATOR,
    VIEWER
}
