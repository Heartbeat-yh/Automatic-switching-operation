package com.example.collabops.domain;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "automation_rule")
public class AutomationRule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false, length=128)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable=false, length=64)
    private AutomationTrigger triggerType;

    @Enumerated(EnumType.STRING)
    @Column(nullable=false, length=64)
    private AutomationAction actionType;

    @Column(length=500)
    private String actionConfig;

    @Column(nullable=false)
    private Boolean enabled;

    private LocalDateTime createdAt;
}
