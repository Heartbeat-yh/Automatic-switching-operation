package com.example.collabops.domain;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "sys_user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false, unique=true, length=64)
    private String username;

    @Column(nullable=false)
    private String password;

    @Column(nullable=false, length=64)
    private String realName;

    @Enumerated(EnumType.STRING)
    @Column(nullable=false, length=32)
    private Role role;

    @Column(nullable=false)
    private Boolean enabled;

    private LocalDateTime createdAt;
}
