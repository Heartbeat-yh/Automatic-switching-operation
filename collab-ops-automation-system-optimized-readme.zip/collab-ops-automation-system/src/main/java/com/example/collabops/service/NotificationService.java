package com.example.collabops.service;

import com.example.collabops.domain.Notification;
import com.example.collabops.domain.User;
import com.example.collabops.repository.NotificationRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class NotificationService {
    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    public void create(User receiver, String title, String content) {
        if (receiver == null) {
            return;
        }
        notificationRepository.save(Notification.builder()
                .receiver(receiver)
                .title(title)
                .content(content)
                .readFlag(false)
                .createdAt(LocalDateTime.now())
                .build());
    }

    public List<Notification> list(Long userId) {
        return notificationRepository.findByReceiverIdOrderByCreatedAtDesc(userId);
    }
}
