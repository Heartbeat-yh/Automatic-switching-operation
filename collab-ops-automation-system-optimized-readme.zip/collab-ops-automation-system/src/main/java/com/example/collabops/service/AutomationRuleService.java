package com.example.collabops.service;

import com.example.collabops.domain.AutomationRule;
import com.example.collabops.dto.AutomationRuleRequest;
import com.example.collabops.repository.AutomationRuleRepository;
import com.example.collabops.security.CurrentUser;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AutomationRuleService {
    private final AutomationRuleRepository repository;
    private final AuditService auditService;
    private final CurrentUser currentUser;

    public AutomationRuleService(AutomationRuleRepository repository, AuditService auditService, CurrentUser currentUser) {
        this.repository = repository;
        this.auditService = auditService;
        this.currentUser = currentUser;
    }

    public List<AutomationRule> list() {
        return repository.findAll();
    }

    public AutomationRule create(AutomationRuleRequest request) {
        AutomationRule rule = AutomationRule.builder()
                .name(request.getName())
                .triggerType(request.getTriggerType())
                .actionType(request.getActionType())
                .actionConfig(request.getActionConfig())
                .enabled(request.getEnabled())
                .createdAt(LocalDateTime.now())
                .build();
        repository.save(rule);
        auditService.log(currentUser.username(), "CREATE_AUTOMATION_RULE", "RULE", String.valueOf(rule.getId()), rule.getName());
        return rule;
    }
}
