package com.example.collabops.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.collabops.domain.TaskComment;import java.util.List;public interface TaskCommentRepository extends JpaRepository<TaskComment, Long>{ List<TaskComment> findByTaskIdOrderByCreatedAtAsc(Long taskId); }
