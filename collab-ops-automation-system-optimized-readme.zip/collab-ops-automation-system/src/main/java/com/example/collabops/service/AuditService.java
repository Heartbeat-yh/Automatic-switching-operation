package com.example.collabops.service;

import com.example.collabops.domain.AuditLog;
import com.example.collabops.repository.AuditLogRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AuditService {
    private final AuditLogRepository auditLogRepository;

    public AuditService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    public void log(String operator, String action, String bizType, String bizId, String detail) {
        auditLogRepository.save(AuditLog.builder()
                .operator(operator)
                .action(action)
                .bizType(bizType)
                .bizId(bizId)
                .detail(detail)
                .createdAt(LocalDateTime.now())
                .build());
    }
}
