package com.example.collabops.service;

import com.example.collabops.domain.*;
import com.example.collabops.repository.AutomationRuleRepository;
import com.example.collabops.repository.OpsTaskRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AutomationService {
    private final AutomationRuleRepository ruleRepository;
    private final NotificationService notificationService;
    private final OpsTaskRepository taskRepository;

    public AutomationService(AutomationRuleRepository ruleRepository,
                             NotificationService notificationService,
                             OpsTaskRepository taskRepository) {
        this.ruleRepository = ruleRepository;
        this.notificationService = notificationService;
        this.taskRepository = taskRepository;
    }

    @Transactional
    public void trigger(AutomationTrigger trigger, OpsTask task) {
        List<AutomationRule> rules = ruleRepository.findByEnabledTrueAndTriggerType(trigger);
        for (AutomationRule rule : rules) {
            if (rule.getActionType() == AutomationAction.CREATE_NOTIFICATION) {
                notificationService.create(
                        task.getAssignee(),
                        "自动化提醒：" + task.getTitle(),
                        rule.getActionConfig() == null ? "有新的协同任务需要处理" : rule.getActionConfig()
                );
            }
            if (rule.getActionType() == AutomationAction.MARK_IN_PROGRESS
                    && task.getStatus() == TaskStatus.TODO) {
                task.setStatus(TaskStatus.IN_PROGRESS);
                taskRepository.save(task);
                notificationService.create(task.getAssignee(), "紧急任务已自动进入处理中", task.getTitle());
            }
        }
    }
}
