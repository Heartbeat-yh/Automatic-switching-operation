let token = localStorage.getItem("token") || "";
let currentUser = JSON.parse(localStorage.getItem("currentUser") || "null");

function authHeaders() {
    return {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + token
    };
}

function renderUser() {
    document.getElementById("userInfo").innerHTML = currentUser
        ? `当前用户：${currentUser.realName} <span class="badge">${currentUser.role}</span>`
        : "未登录";
}

async function request(url, options = {}) {
    const res = await fetch(url, options);
    const json = await res.json();
    if (!json.success) {
        alert(json.message || "请求失败");
        throw new Error(json.message);
    }
    return json.data;
}

async function login() {
    const data = await request("/api/auth/login", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            username: document.getElementById("username").value,
            password: document.getElementById("password").value
        })
    });
    token = data.token;
    currentUser = data;
    localStorage.setItem("token", token);
    localStorage.setItem("currentUser", JSON.stringify(currentUser));
    renderUser();
    await loadUsers();
    await loadTasks();
    await loadRules();
    await loadNotifications();
}

async function loadUsers() {
    const users = await request("/api/users", {headers: authHeaders()});
    const select = document.getElementById("assignee");
    select.innerHTML = users.map(u => `<option value="${u.id}">${u.realName}（${u.role}）</option>`).join("");
}

async function createTask() {
    await request("/api/tasks", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({
            title: document.getElementById("taskTitle").value,
            description: document.getElementById("taskDesc").value,
            priority: document.getElementById("priority").value,
            assigneeId: Number(document.getElementById("assignee").value)
        })
    });
    document.getElementById("taskTitle").value = "";
    document.getElementById("taskDesc").value = "";
    await loadTasks();
    await loadNotifications();
}

async function loadTasks() {
    const tasks = await request("/api/tasks", {headers: authHeaders()});
    document.getElementById("tasks").innerHTML = tasks.map(t => `
        <div class="item">
            <strong>${t.title}</strong>
            <span class="badge">${t.status}</span>
            <span class="badge">${t.priority}</span>
            <div class="muted">创建人：${t.creator ? t.creator.realName : "-"}，负责人：${t.assignee ? t.assignee.realName : "-"}</div>
            <p>${t.description || ""}</p>
            <div class="actions">
                <button onclick="changeStatus(${t.id}, 'IN_PROGRESS')">处理中</button>
                <button onclick="changeStatus(${t.id}, 'BLOCKED')" class="secondary">阻塞</button>
                <button onclick="changeStatus(${t.id}, 'DONE')">完成</button>
                <button onclick="addComment(${t.id})" class="secondary">评论</button>
            </div>
        </div>
    `).join("");
}

async function changeStatus(id, status) {
    await request(`/api/tasks/${id}/status`, {
        method: "PUT",
        headers: authHeaders(),
        body: JSON.stringify({status})
    });
    await loadTasks();
}

async function addComment(id) {
    const content = prompt("请输入评论内容");
    if (!content) return;
    await request(`/api/tasks/${id}/comments`, {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify({content})
    });
    alert("评论成功");
}

async function loadRules() {
    const rules = await request("/api/automation-rules", {headers: authHeaders()});
    document.getElementById("rules").innerHTML = rules.map(r => `
        <div class="item">
            <strong>${r.name}</strong>
            <span class="badge">${r.triggerType}</span>
            <span class="badge">${r.actionType}</span>
            <div class="muted">${r.actionConfig || ""}</div>
        </div>
    `).join("");
}

async function loadNotifications() {
    const list = await request("/api/notifications", {headers: authHeaders()});
    document.getElementById("notifications").innerHTML = list.map(n => `
        <div class="item">
            <strong>${n.title}</strong>
            <div class="muted">${n.createdAt || ""}</div>
            <p>${n.content}</p>
        </div>
    `).join("");
}

renderUser();
if (token) {
    loadUsers().then(loadTasks).then(loadRules).then(loadNotifications).catch(() => {});
}
