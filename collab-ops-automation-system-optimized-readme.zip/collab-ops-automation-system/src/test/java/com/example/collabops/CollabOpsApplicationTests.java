package com.example.collabops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollabOpsApplicationTests {
    @Test
    void contextLoads() {
    }
}
